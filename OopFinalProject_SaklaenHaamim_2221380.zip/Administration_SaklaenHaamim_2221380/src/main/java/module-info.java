module com.example.administration_saklaenhaamim_2221380 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.administration_saklaenhaamim_2221380 to javafx.fxml;
    exports com.example.administration_saklaenhaamim_2221380;
}