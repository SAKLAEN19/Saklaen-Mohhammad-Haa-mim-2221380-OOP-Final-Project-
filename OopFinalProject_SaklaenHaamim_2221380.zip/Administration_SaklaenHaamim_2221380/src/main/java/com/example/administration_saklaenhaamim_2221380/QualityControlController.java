package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;

public class QualityControlController {

    @FXML
    private RadioButton bsmpRadio;

    @FXML
    private RadioButton cosRadio;

    @FXML
    private RadioButton csRadio;

    @FXML
    private RadioButton ctmRadio;

    @FXML
    private RadioButton gslbsRadio;

    @FXML
    private RadioButton mgcjrRadio;

    @FXML
    private RadioButton pavRadio;

    @FXML
    private Button saveOnButton;

    @FXML
    private RadioButton ssdcRadio;

    @FXML
    private RadioButton tmpRadio;

    @FXML
    private RadioButton vbRadio;

    @FXML
    void handleReturnButton(ActionEvent event) {

    }

}

