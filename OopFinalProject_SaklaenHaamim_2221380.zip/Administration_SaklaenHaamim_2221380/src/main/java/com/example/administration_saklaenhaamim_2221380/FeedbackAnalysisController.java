package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;

public class FeedbackAnalysisController {

    @FXML
    private Button SaveButton;

    @FXML
    private TableColumn<?, ?> mealTC;

    @FXML
    private RadioButton negRadio;

    @FXML
    private RadioButton neuRadio;

    @FXML
    private RadioButton posRadio;

    @FXML
    private Button returnnOnButton;

    @FXML
    private TableColumn<?, ?> sgTC;

    @FXML
    private TableColumn<?, ?> sqTC;

    @FXML
    void handleReturnButton(ActionEvent event) {

    }

    @FXML
    void handleSaveButton(ActionEvent event) {

    }

}
