package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;

public class DeleteServiceController {

    @FXML
    private Button DeleteButton;

    @FXML
    private TableColumn<?, ?> avlTF;

    @FXML
    private TextField mealField;

    @FXML
    private TableColumn<?, ?> nameTF;

    @FXML
    private TextField priceFeld;

    @FXML
    private TableColumn<?, ?> priceTF;

    @FXML
    private Button returnnOnButton;

    @FXML
    private TableColumn<?, ?> typeTF;

    @FXML
    void handleReturnButton(ActionEvent event) {

    }

    @FXML
    void handledeleteButton(ActionEvent event) {

    }

}


