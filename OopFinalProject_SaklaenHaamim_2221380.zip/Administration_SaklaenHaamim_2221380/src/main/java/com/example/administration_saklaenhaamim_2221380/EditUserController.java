package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class EditUserController {

    @FXML
    private TextField WantoeditButton;

    @FXML
    private DatePicker dateOfJoiningPicker;

    @FXML
    private TextField departmentField;

    @FXML
    private Button editUserButton;

    @FXML
    private TextField nameField;

    @FXML
    private Button returnHomeButton;

    @FXML
    private TextField userIdField;

    @FXML
    void handleEditUserButton(ActionEvent event) {

    }

    @FXML
    void handleReturnHomeButton(ActionEvent event) {

    }

}
