package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class UpdateServiceController {

    @FXML
    private RadioButton availableRadio;

    @FXML
    private ComboBox<?> melaTypeCombobox;

    @FXML
    private TextField nameField;

    @FXML
    private RadioButton notavailableRadio;

    @FXML
    private TextField priceField;

    @FXML
    private Button returnHomeButton;

    @FXML
    private Button updateServiceButton;

    @FXML
    void handleCreateUserButton(ActionEvent event) {

    }

    @FXML
    void handleReturnHomeButton(ActionEvent event) {

    }

}
