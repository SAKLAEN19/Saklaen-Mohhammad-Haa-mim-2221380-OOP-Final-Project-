package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class CreateUserController {

    @FXML
    private Button createUserButton;

    @FXML
    private DatePicker dateOfJoiningPicker;

    @FXML
    private TextField departmentField;

    @FXML
    private TextField nameField;

    @FXML
    private Button returnHomeButton;

    @FXML
    private TextField userIdField;

    @FXML
    void handleCreateUserButton(ActionEvent event) {

    }

    @FXML
    void handleReturnHomeButton(ActionEvent event) {

    }

}
