package com.example.administration_saklaenhaamim_2221380;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;

public class SearchUserController {

    @FXML
    private Button SearchButton;

    @FXML
    private TableColumn<?, ?> depTF;

    @FXML
    private TableColumn<?, ?> dojTF;

    @FXML
    private TableColumn<?, ?> idTF;

    @FXML
    private TableColumn<?, ?> nameTF;

    @FXML
    private TextField namefiield;

    @FXML
    private Button returnnOnButton;

    @FXML
    private TextField userIIdFeld;

    @FXML
    void handleReturnButton(ActionEvent event) {

    }

    @FXML
    void handleSearchButton(ActionEvent event) {

    }

}